package com.skyline.kattaadminapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.gson.JsonObject;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Iterator;

public class NotificationActivity extends BaseActivity implements AsyncTaskComplete {

    private ActionHandler actionHandler;
    private ArrayList<String> year_selection;
    private ArrayList<String> branch_selection;
    private ArrayList<String> topics;

    private CheckBox checkBox_fy_btech;
    private CheckBox checkBox_sy_btech;
    private CheckBox checkBox_ty;
    private CheckBox checkBox_btech;
    private CheckBox checkBox_cs;
    private CheckBox checkBox_it;
    private CheckBox checkBox_entc;
    private CheckBox checkBox_mech;
    private CheckBox checkBox_instru;
    private CheckBox checkBox_prod;
    private CheckBox checkBox_civil;
    private CheckBox checkBox_electrical;
    private CheckBox checkBox_planning;
    private CheckBox checkBox_fy_mtech;
    private CheckBox checkBox_sy_mtech;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        year_selection = new ArrayList<>();
        branch_selection = new ArrayList<>();
        topics=new ArrayList<>();
        CheckBoxHandler checkBoxHandler = new CheckBoxHandler();

        checkBox_fy_btech = (CheckBox) findViewById(R.id.checkBox_fy_btech);
        checkBox_sy_btech = (CheckBox) findViewById(R.id.checkBox_sy_btech);
        checkBox_ty = (CheckBox) findViewById(R.id.checkBox_ty);
        checkBox_btech = (CheckBox) findViewById(R.id.checkBox_btech);
        checkBox_fy_mtech = (CheckBox) findViewById(R.id.checkBox_sy_mtech);
        checkBox_sy_mtech = (CheckBox) findViewById(R.id.checkBox_fy_mtech);
        checkBox_cs = (CheckBox) findViewById(R.id.checkBox_cs);
        checkBox_it = (CheckBox) findViewById(R.id.checkBox_it);
        checkBox_civil = (CheckBox) findViewById(R.id.checkBox_civil);
        checkBox_instru = (CheckBox) findViewById(R.id.checkBox_instru);
        checkBox_planning = (CheckBox) findViewById(R.id.checkBox_planning);
        checkBox_prod = (CheckBox) findViewById(R.id.checkBox_prod);
        checkBox_mech = (CheckBox) findViewById(R.id.checkBox_mech);
        checkBox_entc = (CheckBox) findViewById(R.id.checkBox_entc);
        checkBox_electrical = (CheckBox) findViewById(R.id.checkBox_electrical);

        checkBox_fy_btech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_sy_btech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_ty.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_btech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_fy_mtech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_sy_mtech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_cs.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_it.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_civil.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_instru.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_planning.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_prod.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_mech.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_entc.setOnCheckedChangeListener(checkBoxHandler);
        checkBox_electrical.setOnCheckedChangeListener(checkBoxHandler);


        actionHandler = new ActionHandler(NotificationActivity.this, this);
    }

    public void onClickSend(View view) {
        EditText edittext_notification = (EditText) findViewById(R.id.editTextcustomNotification);
        String text = edittext_notification.getText().toString();
        if (text.isEmpty())
            Toast.makeText(NotificationActivity.this, "Can't send a blank notification!!", Toast.LENGTH_SHORT).show();
        else {
            String year,branch;
            int i ,j;
            topics.clear();
            if(year_selection.size()==0)
                year_selection.add("");
            if(branch_selection.size()==0)
                branch_selection.add("");
            for(i=0;i<year_selection.size();i++){
                year=year_selection.get(i);
                j=0;
                for(j=0;j<branch_selection.size();j++){
                    branch=branch_selection.get(j);
                    topics.add("clients"+year+branch);
                    Log.d("Notification","Sending to : clients"+year+branch);
                }
            }
            year_selection.remove("");
            branch_selection.remove("");
            actionHandler.sendnotification(topics,text);
        }
    }

    @Override
    public void handleResult(JsonObject input, JsonObject result, String action) throws JSONException {
        if(result.get("success").getAsInt()==1) {
            Toast.makeText(NotificationActivity.this, "All users will be notified shortly!", Toast.LENGTH_SHORT).show();
            ((EditText) findViewById(R.id.editTextcustomNotification)).setText("");
        }
    }

    private class CheckBoxHandler implements CheckBox.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            switch (buttonView.getId()) {
                case R.id.checkBox_fy_btech:
                    if (isChecked)
                        year_selection.add("_First_Year_BTech");
                    else
                        year_selection.remove("_First_Year_BTech");
                    break;
                case R.id.checkBox_sy_btech:
                    if (isChecked)
                        year_selection.add("_Second_Year_BTech");
                    else
                        year_selection.remove("_Second_Year_BTech");
                    break;
                case R.id.checkBox_fy_mtech:
                    if (isChecked)
                        year_selection.add("_First_Year_MTech");
                    else
                        year_selection.remove("_First_Year_MTech");
                    break;
                case R.id.checkBox_sy_mtech:
                    if (isChecked)
                        year_selection.add("_Second_Year_MTech");
                    else
                        year_selection.remove("_Second_Year_MTech");
                    break;
                case R.id.checkBox_ty:
                    if (isChecked)
                        year_selection.add("_Third_Year");
                    else
                        year_selection.remove("_Third_Year");
                    break;
                case R.id.checkBox_btech:
                    if (isChecked)
                        year_selection.add("_Fourth_Year");
                    else
                        year_selection.remove("_Fourth_Year");
                    break;
                case R.id.checkBox_cs:
                    if(isChecked)
                        branch_selection.add("_Computer");
                    else
                        branch_selection.remove("_Computer");
                    break;
                case R.id.checkBox_mech:
                    if(isChecked)
                        branch_selection.add("_Mechanical");
                    else
                        branch_selection.remove("_Mechanical");
                    break;
                case R.id.checkBox_it:
                    if(isChecked)
                        branch_selection.add("_IT");
                    else
                        branch_selection.remove("_IT");
                    break;
                case R.id.checkBox_entc:
                    if(isChecked)
                        branch_selection.add("_ENTC");
                    else
                        branch_selection.remove("_ENTC");
                    break;
                case R.id.checkBox_electrical:
                    if(isChecked)
                        branch_selection.add("_Electrical");
                    else
                        branch_selection.remove("_Electrical");
                    break;
                case R.id.checkBox_civil:
                    if(isChecked)
                        branch_selection.add("_Civil");
                    else
                        branch_selection.remove("_Civil");
                    break;
                case R.id.checkBox_prod:
                    if(isChecked)
                        branch_selection.add("_Production");
                    else
                        branch_selection.remove("_Production");
                    break;
                case R.id.checkBox_planning:
                    if(isChecked)
                        branch_selection.add("_Planning");
                    else
                        branch_selection.remove("_Planning");
                    break;
                case R.id.checkBox_instru:
                    if(isChecked)
                        branch_selection.add("_Instrumentation");
                    else
                        branch_selection.remove("_Instrumentation");
                    break;
            }
        }
    }
}
